import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;

import java.util.ArrayList;
import java.util.List;

public class Settings {
    private String startWord;
    private String endWord;
    private String outputType;
    private String dequeType;
    private String checkpoint;
    private ArrayList<String> dictionary;
    private ArrayList<String> actions;

    // used by getOpt to tell us which flag is being processed
    private int choice;

    // specify all of the long options for this program
    LongOpt[] longOptions = {
            new LongOpt("stack", LongOpt.NO_ARGUMENT, null, 's'),
            new LongOpt("queue", LongOpt.NO_ARGUMENT, null, 'q'),
            new LongOpt("change", LongOpt.NO_ARGUMENT, null, 'c'),
            new LongOpt("swap", LongOpt.NO_ARGUMENT, null, 'p'),
            new LongOpt("length", LongOpt.NO_ARGUMENT, null, 'l'),
            new LongOpt("output", LongOpt.REQUIRED_ARGUMENT, null, 'o'),
            new LongOpt("begin", LongOpt.REQUIRED_ARGUMENT, null, 'b'),
            new LongOpt("end", LongOpt.REQUIRED_ARGUMENT, null, 'e'),
            new LongOpt("help", LongOpt.NO_ARGUMENT, null, 'h'),
            new LongOpt("checkpoint1", LongOpt.NO_ARGUMENT, null, 'x'),
            new LongOpt("checkpoint2", LongOpt.NO_ARGUMENT, null, 'y')
    };

    // constructor
    public Settings(String[] args, ArrayList<String> words) {
        this.actions = new ArrayList<String>();
        this.dictionary = new ArrayList<String>();
        this.startWord = "";
        this.endWord = "";
        this.outputType = "";
        this.dequeType = "";
        this.checkpoint = "";
        // create the object that processes command line arguments
        Getopt g = new Getopt("Project1", args, "b:ce:hlo:pqsxy", this.longOptions);
        g.setOpterr(true);      // prints err messages for us when we make a mistake
        writeDictionary(words, this.dictionary);

        // process one command line argument at a time until there are none left
        // g.getopt() returns an int representing the short flag or -1 if we are done
        while((this.choice = g.getopt()) != -1) {
            // we need to process the command line argument stored in choice
            switch(this.choice) {
                case 'b':
                    // check if beginning term is already set
                    if(!this.startWord.isBlank()) {
                        System.err.println("Error: beginning term already set to " + this.startWord);
                        System.exit(1);
                    }
                    // set the beginning term
                    String start = g.getOptarg();
                    // check if beginning term is in the dictionary 'words'
                    if(this.dictionary.indexOf(start) == -1){
                        System.err.println("Error: -b argument " + start + " not in dictionary");
                        System.exit(1);
                    }
                    this.startWord = start;
                    break;

                case 'c':
                    if(this.actions.contains("change")) {
                        System.err.println("Change mode already accepted; program will continue");
                        break;
                    }
                    this.actions.add("change");
                    break;

                case 'e':
                    // check if end term is already set
                    if(!this.endWord.isBlank()) {
                        System.err.println("Error: end term already set to" + this.endWord);
                        System.exit(1);
                    }
                    // set the end term
                    String end = g.getOptarg();
                    // check if end term is in the dictionary 'words'
                    if(this.dictionary.indexOf(end) == -1){
                        System.err.println("Error: -e argument " + end + " not in dictionary");
                        System.exit(1);
                    }
                    this.endWord = end;
                    break;

                case 'h':
                    printHelp();
                    System.exit(0);

                case 'l':
                    if(this.actions.contains("length")) {
                        System.err.println("Length mode already accepted; program will continue");
                        break;
                    }
                    this.actions.add("length");
                    break;

                case 'o':
                    if(!this.outputType.isBlank()) {
                        System.err.println("Error: output type already set to " + this.outputType);
                        System.exit(1);
                    }
                    String output = g.getOptarg();
                    if(output.equals("W") && output.equals("M")) {
                        System.err.println("Error: invalid output type");
                        System.exit(1);
                    }
                    this.outputType = output;
                    break;

                case 'p':
                    if(this.actions.contains("swap")) {
                        System.err.println("Swap mode already accepted; program will continue");
                        break;
                    }
                    actions.add("swap");
                    break;

                case 'q':
                    if(!this.dequeType.isBlank()) {
                        System.err.println("Error: deque type already processed");
                        System.exit(1);
                    }
                    this.dequeType = "queue";
                    break;

                case 's':
                    if(!this.dequeType.isBlank()) {
                        System.err.println("Error: deque type already processed");
                        System.exit(1);
                    }
                    this.dequeType = "stack";
                    break;

                case 'x':
                    if(!this.checkpoint.isBlank()) {
                        System.err.println("Checkpoint already established; program will continue");
                        break;
                    }
                    this.checkpoint = "x";
                    break;

                case 'y':
                    if(!this.checkpoint.isBlank()) {
                        System.err.println("Checkpoint already established; program will continue");
                        break;
                    }
                    this.checkpoint = "y";
                    break;

                default:
                    System.err.println("Error: invalid option");
                    System.exit(1);
            }
        }

        if(this.dequeType.isBlank() || this.startWord.isBlank() || this.endWord.isBlank() || this.actions.isEmpty()) {
            System.err.println("Error: not enough specifications");
            System.exit(1);
        }
        if(this.checkpoint.isBlank()) {
            System.err.println("Error: At this time, checkpoint must be specified");
            System.exit(1);
        }
        if(this.outputType.isBlank()) {
            this.outputType = "W";
        }
    }

    // instance methods
    public static void printHelp() {
        System.out.println("Usage: java [options] main [-s], [-q], [-c], [-p], [-l], [-o W|M], [-b]<word>, [-e<word>], [-h], [-x], [-y]");
        System.out.println("This program takes either a simple or complex dictionary, and finds a path from the beginning " +
                "word (-b) to the end word (-e) through the user-selected morph modes (see below)\n ●--stack, -s: If this flag is set, use the stack-based routing scheme.\n" +
                " ●--queue, -q: If this flag is set, use the queue-based routing scheme.\n" +
                " ●--change, -c: If this flag is set, Letterman is allowed to change one\n" +
                "        letter into another.\n" +
                " ●--swap, -p: If this flag is set, Letterman is allowed to\n" +
                "        swap any two adjacent characters.\n" +
                " ●--length, -l: If this flag is set, Letterman is allowed to modify\n" +
                "        the length of a word, by inserting or deleting a single letter.\n" +
                " ●--output (W|M),  -o (W|M): Indicates the output file format by\n" +
                "        following the flag with a W(word format) or M (modification format).\n" +
                "         If the --output option is not specified, default to word output format (W).\n" +
                "         If --output is specified on the command line, the argument(either W or M)\n" +
                "         to it is required. \n" +
                " ●--begin <word>, -b <word>: This specifies the word that Letterman starts with.\n" +
                "        This flag must be specified on the command line, and when it is specified a word\n" +
                "        must follow it.\n" +
                " ●--end <word>, -e <word>: This specifies the word that Letterman must reach.\n" +
                "        This flag must be specified on the command line, and when it is\n" +
                "        specified a word must follow it.\n" +
                " ●--help, -h: If this switch is set, the program should print a brief help message\n" +
                "        which describes what the program does and what each of the flags are.\n" +
                "        The program should then System.exit(0) or return from main().\n" +
                " ●--checkpoint1, -x: stop the program after completing checkpoint 1 (see Grading)\n" +
                " ●--checkpoint2, -y: stop the program after completing checkpoint 2 (see Grading)");
    }
    public String getStart() {
        return this.startWord;
    }
    public String getEnd() {
        return this.endWord;
    }
    public String getOutputType() {
        return this.outputType;
    }
    public String getDequeType() {
        return this.dequeType;
    }
    public String getCheckpoint() {
        return this.checkpoint;
    }
    public ArrayList<String> getDictionary() {
        return this.dictionary;
    }
    public ArrayList<String> getActions() {
        return this.actions;
    }
    public void writeDictionary(ArrayList<String> terms, ArrayList<String> dict) {
        // the first line in the file of words is the complexity, S or C
        if(terms.get(0).equals("S")) {
            for(int i = 2; i < terms.size(); i++) {
                if(terms.get(i).contains("//")) {      // should make a check to ensure there's no number line
                    break;
                }
                dict.add(terms.get(i));
                }
            if(dict.size() != Integer.parseInt(terms.get(1))) {
                System.err.println("Error: number of words in dictionary does not match source file");
                System.exit(1);
            }
        }
        else if(terms.get(0).equals("C")) {
            complexDictionary(terms, dict);
        }
        else {
            System.err.println("Error: Dictionary type not defined");
            System.exit(1);
        }
    }
    public void complexDictionary(ArrayList<String> terms, ArrayList<String> dict) {
        for(String w : terms) {
            if(w.contains("//")) {
                break;
            }
            if(w.contains("&") || w.contains("[") || w.contains("!") || w.contains("?")) {
                char[] term = w.toCharArray();
                for (int i = 0; i < w.length(); i++) {
                    if (w.charAt(i) == '&') {
                        dict.add(String.copyValueOf(term, 0, w.length()-1));
                        char[] revTerm = new char[w.length()-1];
                        for(int n = w.length()-1; n > 0; n--) {
                            revTerm[w.length() - n] = term[n];
                        }
                        dict.add(String.copyValueOf(revTerm,0,w.length()-1));
                    }
                    else if (w.charAt(i) == '[') {
                        String prefix = String.copyValueOf(term, 0, i-1);
                        String suffix1 = String.copyValueOf(term, i+1, w.length()-i-1);
                        int s = suffix1.indexOf(']');
                        String suffix = String.copyValueOf(term, s+1, w.length()-s-1);
                        int n = 1;
                        while(w.charAt(n) != ']') {
                            dict.add(prefix + w.charAt(i+n) + suffix);
                        }
                    }
                    else if (w.charAt(i) == '!') {
                        String prefix = (String.copyValueOf(term,0, i-2));
                        String suffix = String.copyValueOf(term, i+1, w.length()-(i+1));
                        dict.add(prefix + w.charAt(i-2) + w.charAt(i-1) + suffix);
                        dict.add(prefix + w.charAt(i-1) + suffix);
                    }
                    else if (w.charAt(i) == '?') {
                        String prefix = (String.copyValueOf(term,0, i-1));
                        String suffix = String.copyValueOf(term, i+1, w.length() - (w.length()-i-1));
                        dict.add(prefix+suffix);
                        dict.add(prefix + w.charAt(i-1) + suffix);
                    }
                }
            }
            else {
                dict.add(w);
            }
            if(dict.size() != Integer.parseInt(terms.get(1))) {
                System.err.println("Error: number of words in dictionary does not match source file");
                System.exit(1);
            }
        }
    }
}
