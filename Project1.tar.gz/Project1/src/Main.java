import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // process command line arguments to get dictionary words
        Scanner in = new Scanner(System.in).useLocale(Locale.US);
        ArrayList<String> words = new ArrayList<String>();

        int i = 0;
        while(in.hasNextLine()) {
            words.add(in.nextLine());
        }
        Settings settings = new Settings(args, words);
        executeCheckpoint(settings);

    }

    // method to allow program to operate the functions expected at the
    // checkpoint specified in the command line and Settings
    private static void executeCheckpoint(Settings s) {
        if(s.getCheckpoint().equals("x")) {
            System.out.println("Words in dictionary: " + s.getDictionary().size());
        }
    }
}

